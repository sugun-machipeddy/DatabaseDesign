SELECT avg(goals)
FROM Players;
