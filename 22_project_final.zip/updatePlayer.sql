UPDATE Players
SET salary=-1
WHERE name='Wayne Gretzky';
