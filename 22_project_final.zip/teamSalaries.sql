SELECT teamName, avg(salary)
FROM Players
GROUP BY teamName;
