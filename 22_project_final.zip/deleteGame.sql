DELETE
FROM Games
WHERE gameId=9;
