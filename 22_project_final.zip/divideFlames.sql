INSERT INTO Games(homeTeam,homeCity,homeScore,gameId,startTime,awayTeam,awayCity,awayScore) VALUES ('Canucks','Vancouver',3,10,to_date('2018-03-22 16:00:00', 'yyyy-mm-dd hh24-mi-ss'),'Flames','Calgary',2);

INSERT INTO GameLocations(gameId,address) VALUES (10,'800 Griffiths Way, Vancouver, BC V6B 6G1');


